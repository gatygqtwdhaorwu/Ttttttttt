================================================================
  MIM Store Online - Full Public Dump
  الموقع: https://www.themimstore.org (Mimmostore.org)
  التاريخ: $(date)
================================================================

[معلومات الموقع]
- المنصة: Shopify
- اسم المتجر: themimstoreonline.myshopify.com
- Store ID: 01494302
- Theme ID: 127758958658
- الثيم: Flex v5.2.1 (Out of the Sandbox)
- البريد الإلكتروني: museumstore@mim.org
- الهاتف: 480.478.6002
- العنوان: 4725 E. Mayo Blvd., Phoenix, AZ 85050

[ملاحظة مهمة]
هذا الموقع مبني على Shopify (SaaS)، وملفات الـ Liquid template
غير متاحة للعامة. الـ Assets (CSS/JS) والبيانات (JSON) تم تحميلها
من المصادر العامة المسموح بها.

[المحتويات]
- assets/       : ملفات CSS و JavaScript الخاصة بالثيم
- pages/        : صفحات HTML كاملة كما تظهر للمستخدم
- json_data/    : بيانات JSON من API (المنتجات, المجموعات)
- images/       : روابط الصور (لتحميلها)
- products/     : (للبيانات الإضافية)

[الأمان - ثغرات مكتشفة]
- collections.json : API مفتوح (يكشف كل المجموعات وعدد المنتجات)
- products.json    : API مفتوح جزئياً
- sitemap.xml      : يكشف كل URLs الموقع
- robots.txt       : متاح
- Admin Panel      : محمي بإحكام (معاد توجيهه)
- .git / .env      : غير مكشوفين (آمن)
